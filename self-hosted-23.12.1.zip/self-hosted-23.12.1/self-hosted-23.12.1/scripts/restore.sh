#!/usr/bin/env bash
cmd=restore
source scripts/_lib.sh
$cmd
