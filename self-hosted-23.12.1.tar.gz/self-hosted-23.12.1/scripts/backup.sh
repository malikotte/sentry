#!/usr/bin/env bash
cmd=backup
source scripts/_lib.sh
$cmd
